import { useState, useEffect, useCallback, useRef, useMemo } from "react";

// ══════════════════════════════════════════════════════════════════════════════
// ALGORITHME SM-2 (SuperMemo-2 fidèle + extensions)
// q: 0=oublié, 3=hésité, 5=facile
// ══════════════════════════════════════════════════════════════════════════════
function sm2(card, q) {
  let { easeFactor = 2.5, interval = 1, repetitions = 0 } = card;
  if (q >= 3) {
    if (repetitions === 0) interval = 1;
    else if (repetitions === 1) interval = 6;
    else interval = Math.round(interval * easeFactor);
    repetitions++;
  } else {
    repetitions = 0;
    interval = 1;
  }
  easeFactor = Math.max(1.3, easeFactor + 0.1 - (5 - q) * (0.08 + (5 - q) * 0.02));
  const nextReview = addDays(today(), interval);
  return { easeFactor: +easeFactor.toFixed(2), interval, repetitions, nextReview };
}

// ══════════════════════════════════════════════════════════════════════════════
// HELPERS DATE
// ══════════════════════════════════════════════════════════════════════════════
const addDays = (date, days) => {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d.toISOString().split("T")[0];
};
const today = () => new Date().toISOString().split("T")[0];
const formatDate = (d) =>
  new Date(d).toLocaleDateString("fr-FR", { day: "2-digit", month: "short" });

// ══════════════════════════════════════════════════════════════════════════════
// BADGES SYSTÈME
// ══════════════════════════════════════════════════════════════════════════════
const BADGES = [
  { id: "first_card", icon: "🌱", label: "Première pousse", desc: "Créer ta 1ère fiche", check: (s) => s.totalCards >= 1 },
  { id: "ten_cards", icon: "📚", label: "Bibliothécaire", desc: "10 fiches créées", check: (s) => s.totalCards >= 10 },
  { id: "fifty_cards", icon: "🗂️", label: "Encyclopédiste", desc: "50 fiches créées", check: (s) => s.totalCards >= 50 },
  { id: "streak3", icon: "🔥", label: "En feu", desc: "3 jours de streak", check: (s) => s.streak >= 3 },
  { id: "streak7", icon: "⚡", label: "Semaine parfaite", desc: "7 jours de streak", check: (s) => s.streak >= 7 },
  { id: "streak30", icon: "🏆", label: "Mois de légende", desc: "30 jours de streak", check: (s) => s.streak >= 30 },
  { id: "first_master", icon: "✅", label: "Premier maître", desc: "1ère fiche maîtrisée", check: (s) => s.mastered >= 1 },
  { id: "ten_master", icon: "🎓", label: "Diplômé", desc: "10 fiches maîtrisées", check: (s) => s.mastered >= 10 },
  { id: "all_reviewed", icon: "🧘", label: "Zen", desc: "0 fiche en retard", check: (s) => s.totalCards > 0 && s.dueCount === 0 },
  { id: "exam_mode", icon: "🎯", label: "Testeur", desc: "Terminer un mode examen", check: (s) => s.examsDone >= 1 },
  { id: "hundred_reviews", icon: "💎", label: "Diamant", desc: "100 révisions totales", check: (s) => s.totalReviews >= 100 },
  { id: "ai_user", icon: "🤖", label: "IA Partner", desc: "Générer 5 fiches via IA", check: (s) => s.aiGenerated >= 5 },
];

// ══════════════════════════════════════════════════════════════════════════════
// CATÉGORIES PAR DÉFAUT
// ══════════════════════════════════════════════════════════════════════════════
const CATEGORIES_DEFAULT = [
  { name: "🇬🇧 Anglais", examDate: "", targetScore: 90, priority: "haute", color: "#4F8EF7" },
  { name: "☕ Java / Spring Boot", examDate: "", targetScore: 85, priority: "haute", color: "#F0A040" },
  { name: "🖥️ Informatique Générale", examDate: "", targetScore: 80, priority: "normale", color: "#40C080" },
];

// ══════════════════════════════════════════════════════════════════════════════
// STORAGE (window.storage — artifact Claude)
// ══════════════════════════════════════════════════════════════════════════════
const storage = {
  async get(key) {
    try {
      const r = await window.storage.get(key);
      return r ? JSON.parse(r.value) : null;
    } catch { return null; }
  },
  async set(key, val) {
    try { await window.storage.set(key, JSON.stringify(val)); } catch {}
  },
};

// ══════════════════════════════════════════════════════════════════════════════
// API CLAUDE
// ══════════════════════════════════════════════════════════════════════════════
async function callGemini(systemPrompt, userMessage, retries = 2) {
  // Remplace par ta vraie clé Gemini
  const apiKey = "AIzaSyA93v5geXNgAcEyUehazhVnoMUPyK6Zdk4"; 
  const endpoint = `https://generativelanguage.googleapis.com/v1/models/gemini-1.5-flash:generateContent?key=${apiKey}`;

  for (let i = 0; i <= retries; i++) {
    try {
      const res = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          systemInstruction: { parts: [{ text: systemPrompt }] },
          contents: [{ parts: [{ text: userMessage }] }],
          generationConfig: { response_mime_type: "application/json" } // Force le format JSON !
        }),
      });

      if (!res.ok) throw new Error(`Status: ${res.status}`);
      const data = await res.json();
      return data.candidates[0].content.parts[0].text;
    } catch (err) {
      if (i === retries) throw err;
      await new Promise(r => setTimeout(r, 1000 * (i + 1)));
    }
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// HEATMAP
// ══════════════════════════════════════════════════════════════════════════════
function buildHeatmap(sessions) {
  const map = {};
  (sessions || []).forEach((s) => { map[s.date] = (map[s.date] || 0) + s.count; });
  return map;
}

function getLast12Weeks() {
  const weeks = [];
  const endDate = new Date();
  const day = endDate.getDay();
  endDate.setDate(endDate.getDate() - day);
  for (let w = 11; w >= 0; w--) {
    const week = [];
    for (let d = 0; d < 7; d++) {
      const dt = new Date(endDate);
      dt.setDate(endDate.getDate() - w * 7 + d);
      week.push(dt.toISOString().split("T")[0]);
    }
    weeks.push(week);
  }
  return weeks;
}

// ══════════════════════════════════════════════════════════════════════════════
// EXPORT / IMPORT
// ══════════════════════════════════════════════════════════════════════════════
function exportData(expressions, categories) {
  const data = { version: 3, exportedAt: new Date().toISOString(), categories, expressions };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `memomaster_backup_${today()}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

function parseImport(text) {
  try {
    const data = JSON.parse(text);
    if (data.expressions && Array.isArray(data.expressions)) {
      return { expressions: data.expressions, categories: data.categories || [] };
    }
  } catch {}
  // Essai CSV simple: front,back,category,example
  try {
    const lines = text.trim().split("\n").filter(Boolean);
    const header = lines[0].split(",").map((h) => h.trim().toLowerCase());
    const expressions = lines.slice(1).map((line) => {
      const vals = line.split(",");
      const obj = {};
      header.forEach((h, i) => { obj[h] = vals[i]?.trim() || ""; });
      return {
        id: Date.now().toString() + Math.random(),
        front: obj.front || obj.recto || "",
        back: obj.back || obj.verso || "",
        example: obj.example || obj.exemple || "",
        category: obj.category || obj.categorie || obj.module || "Import",
        level: 0, nextReview: today(), createdAt: today(),
        easeFactor: 2.5, interval: 1, repetitions: 0, reviewHistory: [],
      };
    }).filter((e) => e.front && e.back);
    return { expressions, categories: [] };
  } catch {}
  return null;
}

// ══════════════════════════════════════════════════════════════════════════════
// COMPOSANT PRINCIPAL
// ══════════════════════════════════════════════════════════════════════════════
export default function MemoMaster() {
  // ── État principal ─────────────────────────────────────────────────────────
  const [view, setView] = useState("dashboard");
  const [expressions, setExpressions] = useState([]);
  const [categories, setCategories] = useState(CATEGORIES_DEFAULT);
  const [sessions, setSessions] = useState([]);
  const [stats, setStats] = useState({ streak: 0, lastSession: null, totalReviews: 0, aiGenerated: 0, examsDone: 0 });
  const [unlockedBadges, setUnlockedBadges] = useState([]);
  const [videos, setVideos] = useState([]); // Ajouté pour intégrer ton code vidéo
  const [ytUrl, setYtUrl] = useState("");   // Ajouté pour intégrer ton code vidéo
  const [loaded, setLoaded] = useState(false);

  // ── État UI ────────────────────────────────────────────────────────────────
  const [toast, setToast] = useState(null);
  const [newBadge, setNewBadge] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [filterCat, setFilterCat] = useState("Toutes");
  const [filterLevel, setFilterLevel] = useState("Tous");

  // ── Révision ───────────────────────────────────────────────────────────────
  const [reviewQueue, setReviewQueue] = useState([]);
  const [reviewIndex, setReviewIndex] = useState(0);
  const [revealed, setRevealed] = useState(false);
  const [reviewSessionDone, setReviewSessionDone] = useState(0);

  // ── Mode examen ────────────────────────────────────────────────────────────
  const [examMode, setExamMode] = useState(false);
  const [examConfig, setExamConfig] = useState({ category: "Toutes", count: 10, timePerCard: 30 });
  const [examActive, setExamActive] = useState(false);
  const [examQueue, setExamQueue] = useState([]);
  const [examIndex, setExamIndex] = useState(0);
  const [examAnswers, setExamAnswers] = useState([]);
  const [examTimer, setExamTimer] = useState(0);
  const [examRevealed, setExamRevealed] = useState(false);
  const examTimerRef = useRef(null);

  // ── Ajout / édition ────────────────────────────────────────────────────────
  const [addForm, setAddForm] = useState({ front: "", back: "", example: "", category: "" });
  const [editingId, setEditingId] = useState(null);
  const [aiPrompt, setAiPrompt] = useState("");
  const [aiLoading, setAiLoading] = useState(false);
  const [listening, setListening] = useState(null);
  const recognitionRef = useRef(null);

  // ── Catégories ─────────────────────────────────────────────────────────────
  const [newCat, setNewCat] = useState({ name: "", examDate: "", targetScore: 80, priority: "normale", color: "#4F8EF7" });
  const [importText, setImportText] = useState("");
  const [showImport, setShowImport] = useState(false);

  // ── Refs pour streak stable ────────────────────────────────────────────────
  const statsRef = useRef(stats);
  useEffect(() => { statsRef.current = stats; }, [stats]);

  // ══════════════════════════════════════════════════════════════════════════
  // CHARGEMENT INITIAL (Fusionné)
  // ══════════════════════════════════════════════════════════════════════════
  useEffect(() => {
    (async () => {
      try {
        const exps = (await storage.get("expressions_v3")) || [];
        const cats = (await storage.get("categories_v3")) || CATEGORIES_DEFAULT;
        const sess = (await storage.get("sessions_v3")) || [];
        const st = (await storage.get("stats_v3")) || { streak: 0, lastSession: null, totalReviews: 0, aiGenerated: 0, examsDone: 0 };
        const badges = (await storage.get("badges_v3")) || [];
        const storedVids = (await storage.get("videos_v3")) || []; // Vidéos intégrées ici

        setExpressions(exps);
        setCategories(cats);
        setSessions(sess);
        setStats(st);
        setUnlockedBadges(badges);
        setVideos(storedVids); 

        setAddForm((f) => ({ ...f, category: cats[0]?.name || "" }));
        setLoaded(true);
      } catch (error) {
        console.error("Erreur lors du chargement des données:", error);
      }
    })();
  }, []);

  // ── Persistance automatique ────────────────────────────────────────────────
  useEffect(() => { if (loaded) storage.set("expressions_v3", expressions); }, [expressions, loaded]);
  useEffect(() => { if (loaded) storage.set("categories_v3", categories); }, [categories, loaded]);
  useEffect(() => { if (loaded) storage.set("sessions_v3", sessions); }, [sessions, loaded]);
  useEffect(() => { if (loaded) storage.set("stats_v3", stats); }, [stats, loaded]);
  useEffect(() => { if (loaded) storage.set("badges_v3", unlockedBadges); }, [unlockedBadges, loaded]);
  useEffect(() => { if (loaded) storage.set("videos_v3", videos); }, [videos, loaded]); // Persistance des vidéos

  // ══════════════════════════════════════════════════════════════════════════
  // BADGES — VÉRIFICATION
  // ══════════════════════════════════════════════════════════════════════════
  const checkBadges = useCallback((exps, st, sess, currentBadges) => {
    const mastered = exps.filter((e) => e.level >= 7).length;
    const dueCount = exps.filter((e) => e.nextReview <= today() && e.level < 7).length;
    const state = {
      totalCards: exps.length, streak: st.streak, mastered, dueCount,
      totalReviews: st.totalReviews, aiGenerated: st.aiGenerated, examsDone: st.examsDone,
    };
    const newlyUnlocked = BADGES.filter(
      (b) => !currentBadges.includes(b.id) && b.check(state)
    );
    if (newlyUnlocked.length > 0) {
      const newIds = [...currentBadges, ...newlyUnlocked.map((b) => b.id)];
      setUnlockedBadges(newIds);
      setNewBadge(newlyUnlocked[0]);
      setTimeout(() => setNewBadge(null), 4000);
    }
  }, []);

  // ══════════════════════════════════════════════════════════════════════════
  // TOAST
  // ══════════════════════════════════════════════════════════════════════════
  const showToast = useCallback((msg, type = "success") => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 3200);
  }, []);

  // ══════════════════════════════════════════════════════════════════════════
  // STREAK — mis à jour APRÈS une session
  // ══════════════════════════════════════════════════════════════════════════
  const updateStreakAfterSession = useCallback((count) => {
    const todayStr = today();
    setStats((prev) => {
      const yesterday = addDays(todayStr, -1);
      let ns = prev.streak;
      if (prev.lastSession === yesterday) ns = prev.streak + 1;
      else if (prev.lastSession !== todayStr) ns = 1;
      const newStats = {
        ...prev,
        streak: ns,
        lastSession: todayStr,
        totalReviews: prev.totalReviews + count,
      };
      statsRef.current = newStats;
      return newStats;
    });
    setSessions((prev) => {
      const existing = prev.find((s) => s.date === todayStr);
      if (existing) return prev.map((s) => s.date === todayStr ? { ...s, count: s.count + count } : s);
      return [...prev, { date: todayStr, count }];
    });
  }, []);

  // ══════════════════════════════════════════════════════════════════════════
  // GÉNÉRATION IA
  // ══════════════════════════════════════════════════════════════════════════
  const handleAIGenerate = async () => {
    if (!aiPrompt.trim()) return;
    setAiLoading(true);
    
    try {
      const catName = addForm.category;
      const isEnglish = catName.toLowerCase().includes("anglais");
      const systemPrompt = `Tu es un assistant pédagogique expert pour un étudiant en Licence Informatique à Dakar, Sénégal.
Génère une fiche de révision en JSON UNIQUEMENT (sans markdown, sans backticks, sans texte avant ou après).
Format strict: {"front":"...","back":"...","example":"..."}
- front: le concept/mot/expression à mémoriser (concis, max 10 mots)
- back: explication claire en français (max 4 lignes, pédagogique et mémorable)
- example: un exemple concret et pratique d'utilisation
${isEnglish ? "Pour l'anglais: front=expression anglaise authentique, back=traduction + usage + nuances en français, example=phrase complète en anglais avec contexte naturel" : ""}
${catName.includes("Java") || catName.includes("Spring") ? "Pour Java/Spring: inclure le contexte d'usage, la syntaxe si pertinente, et quand utiliser ce concept" : ""}`;
      
      const raw = await callGemini(systemPrompt, `Génère une fiche sur: ${aiPrompt}`);
      const clean = raw.replace(/```json|```/g, "").trim();
      const parsed = JSON.parse(clean);
      
      setAddForm((f) => ({ ...f, front: parsed.front || "", back: parsed.back || "", example: parsed.example || "" }));
      showToast("✨ Fiche générée par l'IA !");
      setStats((prev) => ({ ...prev, aiGenerated: prev.aiGenerated + 1 }));
      
      // SUCCÈS : On vide le champ de saisie
      setAiPrompt(""); 
      
    } catch (error) {
      console.error("Détail de l'erreur IA :", error);
      // ÉCHEC : On avertit, mais on NE VIDE PAS aiPrompt pour que tu puisses réessayer
      showToast("Erreur IA. Ton brouillon a été conservé.", "error");
    } finally {
      // FINALLY : S'exécute toujours, succès ou échec, pour arrêter le spinner de chargement
      setAiLoading(false);
    }
  };

  // ══════════════════════════════════════════════════════════════════════════
  // SAISIE VOCALE
  // ══════════════════════════════════════════════════════════════════════════
  const startVoice = (field) => {
    if (!("webkitSpeechRecognition" in window) && !("SpeechRecognition" in window)) {
      showToast("Saisie vocale non supportée (Chrome requis).", "error");
      return;
    }
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    const rec = new SR();
    rec.lang = field === "front" && addForm.category.toLowerCase().includes("anglais") ? "en-US" : "fr-FR";
    rec.continuous = false;
    rec.interimResults = false;
    rec.onresult = (e) => {
      const t = e.results[0][0].transcript;
      setAddForm((f) => ({ ...f, [field]: (f[field] ? f[field] + " " : "") + t }));
      setListening(null);
    };
    rec.onerror = () => { setListening(null); showToast("Erreur micro.", "error"); };
    rec.onend = () => setListening(null);
    recognitionRef.current = rec;
    rec.start();
    setListening(field);
  };
  const stopVoice = () => { recognitionRef.current?.stop(); setListening(null); };

  // ══════════════════════════════════════════════════════════════════════════
  // AJOUTER / ÉDITER UNE FICHE
  // ══════════════════════════════════════════════════════════════════════════
  const handleAdd = () => {
    if (!addForm.front.trim() || !addForm.back.trim()) {
      showToast("Recto et verso obligatoires !", "error");
      return;
    }
    if (editingId) {
      setExpressions((prev) =>
        prev.map((e) =>
          e.id === editingId
            ? { ...e, front: addForm.front.trim(), back: addForm.back.trim(), example: addForm.example.trim(), category: addForm.category }
            : e
        )
      );
      setEditingId(null);
      showToast("✏️ Fiche mise à jour !");
    } else {
      const newExp = {
        id: Date.now().toString(),
        front: addForm.front.trim(), back: addForm.back.trim(),
        example: addForm.example.trim(), category: addForm.category,
        level: 0, nextReview: today(), createdAt: today(),
        easeFactor: 2.5, interval: 1, repetitions: 0, reviewHistory: [],
      };
      setExpressions((prev) => {
        const updated = [newExp, ...prev];
        checkBadges(updated, statsRef.current, sessions, unlockedBadges);
        return updated;
      });
      showToast("✅ Fiche ajoutée !");
    }
    setAddForm((f) => ({ ...f, front: "", back: "", example: "" }));
  };

  const startEdit = (exp) => {
    setAddForm({ front: exp.front, back: exp.back, example: exp.example || "", category: exp.category });
    setEditingId(exp.id);
    setView("add");
  };

  const cancelEdit = () => {
    setEditingId(null);
    setAddForm((f) => ({ ...f, front: "", back: "", example: "" }));
  };

  const deleteExp = (id) => {
    setExpressions((prev) => prev.filter((e) => e.id !== id));
    showToast("Fiche supprimée.", "info");
  };

  // ══════════════════════════════════════════════════════════════════════════
  // RÉVISION SM-2
  // ══════════════════════════════════════════════════════════════════════════
  const todayReviews = useMemo(
    () => expressions.filter((e) => e.nextReview <= today() && e.level < 7),
    [expressions]
  );
  const masteredCount = useMemo(() => expressions.filter((e) => e.level >= 7).length, [expressions]);

  // Priorité intelligente : fiches avec examen proche passent en premier
  const getSmartQueue = useCallback((queue) => {
    return [...queue].sort((a, b) => {
      const catA = categories.find((c) => c.name === a.category);
      const catB = categories.find((c) => c.name === b.category);
      const daysA = catA?.examDate ? Math.ceil((new Date(catA.examDate) - new Date()) / 86400000) : 999;
      const daysB = catB?.examDate ? Math.ceil((new Date(catB.examDate) - new Date()) / 86400000) : 999;
      if (daysA !== daysB) return daysA - daysB;
      return a.easeFactor - b.easeFactor; // les plus difficiles en premier
    });
  }, [categories]);

  const startReview = (catFilter = null) => {
    let queue = catFilter
      ? todayReviews.filter((e) => e.category === catFilter)
      : [...todayReviews];
    queue = getSmartQueue(queue);
    if (queue.length === 0) { showToast("Aucune fiche à réviser !", "info"); return; }
    setReviewQueue(queue);
    setReviewIndex(0);
    setRevealed(false);
    setReviewSessionDone(0);
    setView("review");
  };

  const handleAnswer = (q) => {
    const exp = reviewQueue[reviewIndex];
    const updated = sm2(exp, q);
    const newLevel = q === 0 ? 0 : q === 3 ? Math.max(exp.level, 1) : Math.min(7, exp.level + 1);
    const histEntry = { date: today(), q, newLevel, interval: updated.interval };
    setExpressions((prev) =>
      prev.map((e) =>
        e.id === exp.id
          ? { ...e, ...updated, level: newLevel, reviewHistory: [...(e.reviewHistory || []), histEntry] }
          : e
      )
    );
    const done = reviewSessionDone + 1;
    setReviewSessionDone(done);
    if (reviewIndex + 1 >= reviewQueue.length) {
      updateStreakAfterSession(done);
      setStats((prev) => {
        const ns = { ...prev };
        checkBadges(expressions, ns, sessions, unlockedBadges);
        return ns;
      });
      showToast(`🎉 ${done} carte(s) révisée(s) !`);
      setView("dashboard");
    } else {
      setReviewIndex((i) => i + 1);
      setRevealed(false);
    }
  };

  // ══════════════════════════════════════════════════════════════════════════
  // RACCOURCIS CLAVIER
  // ══════════════════════════════════════════════════════════════════════════
  useEffect(() => {
    const handler = (e) => {
      if (view === "review") {
        if (e.code === "Space" && !revealed) { e.preventDefault(); setRevealed(true); }
        if (revealed) {
          if (e.key === "1") handleAnswer(0);
          if (e.key === "2") handleAnswer(3);
          if (e.key === "3") handleAnswer(5);
        }
      }
      if (view === "exam" && examActive) {
        if (e.code === "Space" && !examRevealed) { e.preventDefault(); setExamRevealed(true); }
        if (examRevealed) {
          if (e.key === "1") handleExamAnswer(0);
          if (e.key === "2") handleExamAnswer(3);
          if (e.key === "3") handleExamAnswer(5);
        }
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [view, revealed, examActive, examRevealed]);

  // ══════════════════════════════════════════════════════════════════════════
  // MODE EXAMEN
  // ══════════════════════════════════════════════════════════════════════════
  const startExam = () => {
    const pool = examConfig.category === "Toutes"
      ? expressions
      : expressions.filter((e) => e.category === examConfig.category);
    if (pool.length === 0) { showToast("Aucune fiche pour cet examen.", "error"); return; }
    const shuffled = [...pool].sort(() => Math.random() - 0.5).slice(0, Math.min(examConfig.count, pool.length));
    setExamQueue(shuffled);
    setExamIndex(0);
    setExamAnswers([]);
    setExamRevealed(false);
    setExamTimer(examConfig.timePerCard);
    setExamActive(true);
  };

  useEffect(() => {
    if (!examActive) return;
    examTimerRef.current = setInterval(() => {
      setExamTimer((t) => {
        if (t <= 1) {
          handleExamAnswer(0); // temps écoulé = oublié
          return examConfig.timePerCard;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(examTimerRef.current);
  }, [examActive, examIndex]);

  const handleExamAnswer = (q) => {
    clearInterval(examTimerRef.current);
    const card = examQueue[examIndex];
    const newAnswers = [...examAnswers, { card, q }];
    setExamAnswers(newAnswers);
    if (examIndex + 1 >= examQueue.length) {
      setExamActive(false);
      setStats((prev) => ({ ...prev, examsDone: prev.examsDone + 1 }));
      checkBadges(expressions, { ...stats, examsDone: stats.examsDone + 1 }, sessions, unlockedBadges);
    } else {
      setExamIndex((i) => i + 1);
      setExamRevealed(false);
      setExamTimer(examConfig.timePerCard);
    }
  };

  const examScore = useMemo(() => {
    if (examAnswers.length === 0) return 0;
    const good = examAnswers.filter((a) => a.q >= 3).length;
    return Math.round((good / examAnswers.length) * 100);
  }, [examAnswers]);

  // ══════════════════════════════════════════════════════════════════════════
  // CATÉGORIES
  // ══════════════════════════════════════════════════════════════════════════
  const handleAddCat = () => {
    if (!newCat.name.trim() || categories.find((c) => c.name === newCat.name.trim())) {
      showToast("Nom invalide ou déjà existant.", "error");
      return;
    }
    setCategories((prev) => [...prev, { ...newCat, name: newCat.name.trim() }]);
    setNewCat({ name: "", examDate: "", targetScore: 80, priority: "normale", color: "#4F8EF7" });
    showToast("Module créé !");
  };

  const deleteCategory = (name) => {
    setCategories((prev) => prev.filter((c) => c.name !== name));
    // Supprimer aussi toutes les fiches associées
    setExpressions((prev) => prev.filter((e) => e.category !== name));
    showToast(`Module "${name}" et ses fiches supprimés.`, "info");
  };

  // ══════════════════════════════════════════════════════════════════════════
  // IMPORT
  // ══════════════════════════════════════════════════════════════════════════
  const handleImport = () => {
    const result = parseImport(importText);
    if (!result) { showToast("Format invalide. JSON ou CSV acceptés.", "error"); return; }
    const { expressions: newExps, categories: newCats } = result;
    setExpressions((prev) => {
      const existing = new Set(prev.map((e) => e.front + e.category));
      const toAdd = newExps.filter((e) => !existing.has(e.front + e.category));
      return [...prev, ...toAdd];
    });
    if (newCats.length > 0) {
      setCategories((prev) => {
        const existing = new Set(prev.map((c) => c.name));
        return [...prev, ...newCats.filter((c) => !existing.has(c.name))];
      });
    }
    setImportText("");
    setShowImport(false);
    showToast(`${newExps.length} fiche(s) importée(s) !`);
  };

  // ══════════════════════════════════════════════════════════════════════════
  // DONNÉES DÉRIVÉES
  // ══════════════════════════════════════════════════════════════════════════
  const heatmap = useMemo(() => buildHeatmap(sessions), [sessions]);
  const weeks = useMemo(() => getLast12Weeks(), []);
  const catNames = useMemo(() => categories.map((c) => c.name), [categories]);

  const filteredExps = useMemo(() => {
    let list = filterCat === "Toutes" ? expressions : expressions.filter((e) => e.category === filterCat);
    if (filterLevel !== "Tous") {
      if (filterLevel === "Maîtrisées") list = list.filter((e) => e.level >= 7);
      else if (filterLevel === "En retard") list = list.filter((e) => e.nextReview <= today() && e.level < 7);
      else if (filterLevel === "Nouvelles") list = list.filter((e) => e.level === 0);
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(
        (e) => e.front.toLowerCase().includes(q) || e.back.toLowerCase().includes(q) || (e.example || "").toLowerCase().includes(q)
      );
    }
    return list;
  }, [expressions, filterCat, filterLevel, searchQuery]);

  const levelLabel = ["Nouveau", "J+1", "J+6", "Adaptatif", "Adaptatif", "Avancé", "Expert", "✅ Maîtrisé"];

  if (!loaded)
    return (
      <div style={s.loading}>
        <div style={s.spinnerWrap}>
          <div style={s.spinner} />
          <div style={s.spinnerRing} />
        </div>
        <p style={s.loadingText}>MémoMaître</p>
        <p style={s.loadingSub}>Chargement de ton espace d'apprentissage...</p>
      </div>
    );

  const currentCard = reviewQueue[reviewIndex];
  const examCurrentCard = examQueue[examIndex];

  // ══════════════════════════════════════════════════════════════════════════
  // RENDER
  // ══════════════════════════════════════════════════════════════════════════
  return (
    <div style={s.app}>
      <style>{CSS}</style>

      {/* ── TOAST ─────────────────────────────────────────────────────────── */}
      {toast && (
        <div style={{ ...s.toast, background: toast.type === "error" ? "#ef4444" : toast.type === "info" ? "#3b82f6" : "linear-gradient(135deg,#4F8EF7,#7B5FF5)" }}>
          {toast.msg}
        </div>
      )}

      {/* ── BADGE NOTIF ──────────────────────────────────────────────────── */}
      {newBadge && (
        <div style={s.badgeNotif}>
          <span style={{ fontSize: 32 }}>{newBadge.icon}</span>
          <div>
            <div style={{ fontWeight: 800, color: "#E0E8FF", fontSize: 15 }}>Badge débloqué !</div>
            <div style={{ color: "#F0A040", fontWeight: 700 }}>{newBadge.label}</div>
            <div style={{ color: "#6B7A99", fontSize: 12 }}>{newBadge.desc}</div>
          </div>
        </div>
      )}

      {/* ── NAV ──────────────────────────────────────────────────────────── */}
      <nav style={s.nav}>
        <div style={s.navBrand}>
          <div style={s.navLogo}>M²</div>
          <div>
            <div style={s.navTitle}>MémoMaître</div>
            <div style={s.navSub}>God Level Edition v3</div>
          </div>
        </div>
        <div style={s.navLinks}>
          {[
            { id: "dashboard", icon: "⚡", label: "Accueil" },
            { id: "add", icon: "✦", label: editingId ? "Éditer" : "Ajouter" },
            { id: "list", icon: "◈", label: "Fiches" },
            { id: "categories", icon: "◉", label: "Modules" },
            { id: "exam", icon: "🎯", label: "Examen" },
            { id: "stats", icon: "▣", label: "Stats" },
            { id: "badges", icon: "🏆", label: "Badges" },
          ].map((n) => (
            <button
              key={n.id}
              onClick={() => setView(n.id)}
              className={view === n.id ? "tab-active" : "hov"}
              style={s.navItem}
            >
              {n.icon} {n.label}
              {n.id === "dashboard" && todayReviews.length > 0 && (
                <span style={s.navBadge}>{todayReviews.length}</span>
              )}
            </button>
          ))}
        </div>
      </nav>

      <main style={s.main}>

        {/* ════════════════════════════════════════════════════════════════
            DASHBOARD
        ════════════════════════════════════════════════════════════════ */}
        {view === "dashboard" && (
          <div style={s.fadeIn}>
            
            {/* 1. En-tête centré */}
            <div style={s.pageHeaderCenter}>
              <h1 style={s.pageTitleCenter}>Bonjour ! 👋</h1>
              <p style={s.pageSubCenter}>Voici ton tableau de bord de révision</p>
            </div>

            {/* 2. Grille de Stats (Exactement 4 cartes) */}
            <div style={s.statsGrid}>
              <div style={s.statCard} className="card-hov">
                <div style={s.statIcon}>🔥</div>
                <div style={s.statNum}>{stats.streak}</div>
                <div style={s.statLabel}>Jours consécutifs</div>
              </div>
              <div style={s.statCard} className="card-hov">
                <div style={s.statIcon}>📦</div>
                <div style={s.statNum}>{expressions.length}</div>
                <div style={s.statLabel}>Fiches au total</div>
              </div>
              <div style={s.statCard} className="card-hov">
                <div style={s.statIcon}>📅</div>
                <div style={s.statNum}>{todayReviews.length}</div>
                <div style={s.statLabel}>À réviser aujourd'hui</div>
              </div>
              <div style={s.statCard} className="card-hov">
                <div style={s.statIcon}>✅</div>
                <div style={s.statNum}>{masteredCount}</div>
                <div style={s.statLabel}>Maîtrisées</div>
              </div>
            </div>

            {/* 3. Bannière Bleue */}
            {todayReviews.length > 0 ? (
              <div style={s.reviewBannerBlue} className="btn-glow">
                <div style={s.bannerTitleWhite}>🎉 {todayReviews.length} révision(s) aujourd'hui !</div>
                <div style={s.bannerSubWhite}>Tu as du pain sur la planche pour maintenir ton streak.</div>
                <div style={{ marginTop: 10, fontSize: 13, color: "rgba(255,255,255,0.8)" }}>
                  ⌨️ Espace = révéler · 1/2/3 = répondre
                </div>
                <button className="hov" onClick={() => startReview()} style={{ ...s.btnWhite, marginTop: 16 }}>
                  Commencer →
                </button>
              </div>
            ) : (
              <div style={s.reviewBannerBlue}>
                <div style={s.bannerTitleWhite}>🎉 Aucune révision aujourd'hui !</div>
                <div style={s.bannerSubWhite}>Tu es à jour. Reviens demain ou ajoute de nouvelles fiches.</div>
              </div>
            )}

            {/* 4. Modules (Adaptés au Light Mode) */}
            <h2 style={s.sectionTitleLight}>⚡ Révision rapide par module</h2>
            <div style={s.modulesGrid}>
              {categories.map((cat) => {
                const catExps = expressions.filter((e) => e.category === cat.name);
                const dueCount = catExps.filter((e) => e.nextReview <= today() && e.level < 7).length;
                const mastered = catExps.filter((e) => e.level >= 7).length;
                const pct = catExps.length ? Math.round((mastered / catExps.length) * 100) : 0;
                const daysToExam = cat.examDate ? Math.ceil((new Date(cat.examDate) - new Date()) / 86400000) : null;
                const catColor = cat.color || "#1D4ED8";
                
                return (
                  <div key={cat.name} style={{ ...s.moduleCardLight, borderTop: `4px solid ${catColor}` }} className="card-hov">
                    <div style={s.moduleNameLight}>{cat.name}</div>
                    {daysToExam !== null && (
                      <div style={{ ...s.examBadge, background: daysToExam <= 7 ? "#FEE2E2" : daysToExam <= 14 ? "#FEF3C7" : "#EFF6FF", color: daysToExam <= 7 ? "#EF4444" : daysToExam <= 14 ? "#D97706" : catColor }}>
                        📅 {daysToExam > 0 ? `J-${daysToExam}` : daysToExam === 0 ? "Examen aujourd'hui !" : "Passé"}
                      </div>
                    )}
                    <div style={s.progressWrap}>
                      <div style={s.progressTrackLight}>
                        <div style={{ ...s.progressFillLight, width: `${pct}%`, background: pct >= (cat.targetScore || 80) ? "#10B981" : catColor }} />
                      </div>
                      <span style={{ ...s.pctLabel, color: catColor }}>{pct}%</span>
                    </div>
                    <div style={s.moduleStats}>
                      <span style={{ color: "#6B7280", fontSize: 13 }}>{catExps.length} fiches · obj. {cat.targetScore}%</span>
                      {dueCount > 0 && (
                        <button onClick={() => startReview(cat.name)} className="hov" style={{ ...s.quickReviewBtn, background: catColor, color: "white" }}>
                          {dueCount} à réviser →
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* 5. Prochaines révisions (Adaptées au Light Mode) */}
            {expressions.length > 0 && (
              <>
                <h2 style={s.sectionTitleLight}>🗓️ Prochaines échéances</h2>
                <div style={s.upcomingList}>
                  {[...expressions]
                    .filter((e) => e.level < 7 && e.nextReview > today())
                    .sort((a, b) => a.nextReview.localeCompare(b.nextReview))
                    .slice(0, 5)
                    .map((e) => (
                      <div key={e.id} style={s.upcomingItemLight}>
                        <span style={s.upcomingFrontLight}>{e.front}</span>
                        <span style={s.upcomingCatLight}>{e.category}</span>
                        <span style={s.upcomingDateLight}>{formatDate(e.nextReview)}</span>
                      </div>
                    ))}
                </div>
              </>
            )}
          </div>
        )}
        {/* ════════════════════════════════════════════════════════════════
            RÉVISION SM-2
        ════════════════════════════════════════════════════════════════ */}
        {view === "review" && currentCard && (
          <div style={s.fadeIn}>
            <div style={s.reviewHeader}>
              <button onClick={() => { setView("dashboard"); if (reviewSessionDone > 0) updateStreakAfterSession(reviewSessionDone); }} style={s.backBtn}>← Quitter</button>
              <div style={s.reviewProgress}>
                <span style={{ color: "#4F8EF7", fontWeight: 800 }}>{reviewIndex + 1}</span>
                <span style={{ color: "#6B7A99" }}> / {reviewQueue.length}</span>
              </div>
            </div>
            <div style={s.progressBar}>
              <div style={{ ...s.progressBarFill, width: `${(reviewIndex / reviewQueue.length) * 100}%` }} />
            </div>

            <div style={s.flashCard} className="card-hov">
              <div style={s.cardTop}>
                <span style={s.catTag}>{currentCard.category}</span>
                <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                  <span style={s.easeTag}>EF: {(currentCard.easeFactor || 2.5).toFixed(1)}</span>
                  <span style={{ ...s.easeTag, background: "#40C08022", color: "#40C080" }}>N{currentCard.level}</span>
                </div>
              </div>
              <div style={s.cardQ}>
                <div style={s.cardQLabel}>QUESTION</div>
                <div style={s.cardQText}>{currentCard.front}</div>
              </div>
              {!revealed ? (
                <>
                  <button className="hov btn-glow" onClick={() => setRevealed(true)} style={s.revealBtn}>
                    👁️ Voir la réponse
                  </button>
                  <div style={s.kbHint}>⌨️ <kbd style={s.kbd}>Espace</kbd> pour révéler</div>
                </>
              ) : (
                <div style={{ animation: "slideIn 0.3s ease" }}>
                  <div style={s.cardA}>
                    <div style={s.cardALabel}>RÉPONSE</div>
                    <div style={s.cardAText}>{currentCard.back}</div>
                    {currentCard.example && (
                      <div style={s.cardEx}>
                        <span style={{ color: "#4F8EF7", fontFamily: "'JetBrains Mono', monospace", fontSize: 11 }}>// exemple</span><br />
                        {currentCard.example}
                      </div>
                    )}
                  </div>
                  <div style={s.answerBtns}>
                    <button className="hov" onClick={() => handleAnswer(0)} style={s.btnOublie}>
                      😓 Oublié<br /><span style={{ fontSize: 11, opacity: 0.8 }}>Retour à zéro</span>
                      <span style={s.kbKey}>1</span>
                    </button>
                    <button className="hov" onClick={() => handleAnswer(3)} style={s.btnHesite}>
                      🤔 Hésité<br /><span style={{ fontSize: 11, opacity: 0.8 }}>Intervalle ×EF/2</span>
                      <span style={s.kbKey}>2</span>
                    </button>
                    <button className="hov" onClick={() => handleAnswer(5)} style={s.btnFacile}>
                      ⚡ Facile<br /><span style={{ fontSize: 11, opacity: 0.8 }}>SM-2 optimisé</span>
                      <span style={s.kbKey}>3</span>
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Historique de la carte */}
            {(currentCard.reviewHistory?.length || 0) > 0 && (
              <div style={s.cardHistory}>
                <span style={{ color: "#6B7A99", fontSize: 12, fontFamily: "JetBrains Mono, monospace" }}>Historique: </span>
                {currentCard.reviewHistory.slice(-7).map((h, i) => (
                  <span key={i} style={{ ...s.histDot, background: h.q === 0 ? "#F04040" : h.q === 3 ? "#F0A040" : "#40C080" }} title={`${h.date} — ${h.q === 0 ? "Oublié" : h.q === 3 ? "Hésité" : "Facile"}`} />
                ))}
              </div>
            )}
          </div>
        )}

        {/* ════════════════════════════════════════════════════════════════
            AJOUTER / ÉDITER
        ════════════════════════════════════════════════════════════════ */}
        {view === "add" && (
          <div style={s.fadeIn}>
            <div style={s.pageHeader}>
              <div>
                <h1 style={s.pageTitle}>{editingId ? "✏️ Éditer la fiche" : "✦ Ajouter une fiche"}</h1>
                <p style={s.pageSub}>{editingId ? "Modifie et sauvegarde ta fiche" : "Manuellement ou via l'Intelligence Artificielle"}</p>
              </div>
              {editingId && (
                <button onClick={cancelEdit} style={s.backBtn}>✕ Annuler l'édition</button>
              )}
            </div>

            {/* Bloc IA */}
            {!editingId && (
              <div style={s.aiBlock}>
                <div style={s.aiHeader}>
                  <span style={s.aiIcon}>🤖</span>
                  <div>
                    <div style={{ fontWeight: 700, color: "#1F2937", fontSize: 15 }}>Génération IA — God Mode</div>
                    <div style={{ color: "#6B7A99", fontSize: 13 }}>Décris un concept, Claude génère la fiche complète</div>
                  </div>
                </div>
                <div style={{ display: "flex", gap: 10, marginTop: 14 }}>
                  <input value={aiPrompt} onChange={(e) => setAiPrompt(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleAIGenerate()}
                    style={s.aiInput} placeholder='Ex: "Polymorphisme Java", "Present Perfect", "Sémaphore"...' />
                  <button className="hov btn-glow" onClick={handleAIGenerate} disabled={aiLoading} style={s.aiBtn}>
                    {aiLoading ? <span style={{ animation: "pulse 1s infinite", display: "inline-block" }}>⏳</span> : "✨ Générer"}
                  </button>
                </div>
              </div>
            )}

            {/* Formulaire */}
            <div style={s.formCard}>
              <div style={s.formGroup}>
                <label style={s.label}>Module / Catégorie</label>
                <select value={addForm.category} onChange={(e) => setAddForm((f) => ({ ...f, category: e.target.value }))} style={s.select}>
                  {catNames.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
              {[
                { field: "front", label: "Recto — Concept / Mot / Expression", placeholder: "Ex: To pull someone's leg / @RestController / Mutex", required: true, multiline: false },
                { field: "back", label: "Verso — Définition / Traduction", placeholder: "Explication claire en français...", required: true, multiline: true },
                { field: "example", label: "Exemple d'utilisation (optionnel)", placeholder: "Un exemple concret...", required: false, multiline: false },
              ].map(({ field, label, placeholder, required, multiline }) => (
                <div key={field} style={s.formGroup}>
                  <label style={s.label}>{label} {required && <span style={{ color: "#F04040" }}>*</span>}</label>
                  <div style={{ position: "relative" }}>
                    {multiline ? (
                      <textarea value={addForm[field]} onChange={(e) => setAddForm((f) => ({ ...f, [field]: e.target.value }))}
                        style={{ ...s.input, minHeight: 90, resize: "vertical", paddingRight: 48 }} placeholder={placeholder} />
                    ) : (
                      <input value={addForm[field]} onChange={(e) => setAddForm((f) => ({ ...f, [field]: e.target.value }))}
                        style={{ ...s.input, paddingRight: 48 }} placeholder={placeholder} />
                    )}
                    <button onClick={() => listening === field ? stopVoice() : startVoice(field)}
                      style={{ ...s.micBtn, color: listening === field ? "#F04040" : "#4F8EF7" }}
                      className={listening === field ? "mic-pulse hov" : "hov"} title="Saisie vocale">
                      🎙️
                    </button>
                  </div>
                  {listening === field && <div style={s.listeningBadge}>🔴 Écoute en cours...</div>}
                </div>
              ))}
              <div style={{ display: "flex", gap: 12 }}>
                <button className="hov btn-glow" onClick={handleAdd} style={s.btnPrimary}>
                  {editingId ? "💾 Sauvegarder" : "✅ Ajouter la fiche"}
                </button>
                {!editingId && (
                  <button className="hov" onClick={() => setAddForm((f) => ({ ...f, front: "", back: "", example: "" }))} style={{ ...s.backBtn, padding: "13px 20px" }}>
                    Réinitialiser
                  </button>
                )}
              </div>
            </div>

            {/* Import */}
            <div style={s.formCard}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
                <div>
                  <div style={{ fontWeight: 700, color: "#1F2937" }}>📤 Import / Export</div>
                  <div style={{ color: "#6B7A99", fontSize: 13 }}>JSON (backup complet) ou CSV (front,back,category,example)</div>
                </div>
                <div style={{ display: "flex", gap: 10 }}>
                  <button className="hov" onClick={() => exportData(expressions, categories)} style={s.btnSecondary}>
                    ⬇️ Exporter
                  </button>
                  <button className="hov" onClick={() => setShowImport((v) => !v)} style={s.btnSecondary}>
                    ⬆️ Importer
                  </button>
                </div>
              </div>
              {showImport && (
                <div style={{ animation: "fadeUp 0.3s ease" }}>
                  <textarea value={importText} onChange={(e) => setImportText(e.target.value)}
                    style={{ ...s.input, minHeight: 120, resize: "vertical", marginBottom: 10, fontFamily: "JetBrains Mono, monospace", fontSize: 12 }}
                    placeholder={"Colle ton JSON ou CSV ici...\n\nCSV format: front,back,category,example"} />
                  <button className="hov" onClick={handleImport} style={s.btnPrimary}>Importer les fiches</button>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ════════════════════════════════════════════════════════════════
            LISTE DES FICHES
        ════════════════════════════════════════════════════════════════ */}
        {view === "list" && (
          <div style={s.fadeIn}>
            <div style={s.pageHeader}>
              <div>
                <h1 style={s.pageTitle}>◈ Mes fiches</h1>
                <p style={s.pageSub}>{filteredExps.length} fiche(s) affichée(s) sur {expressions.length} · {masteredCount} maîtrisée(s)</p>
              </div>
            </div>

            {/* Recherche */}
            <div style={{ position: "relative", marginBottom: 16 }}>
              <span style={{ position: "absolute", left: 16, top: "50%", transform: "translateY(-50%)", fontSize: 16 }}>🔍</span>
              <input value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
                style={{ ...s.input, paddingLeft: 44 }} placeholder="Rechercher dans recto, verso, exemples..." />
            </div>

            {/* Filtres catégorie */}
            <div style={s.filterRow}>
              {["Toutes", ...catNames].map((c) => (
                <button key={c} onClick={() => setFilterCat(c)}
                  className={filterCat === c ? "tab-active hov" : "hov"}
                  style={{ ...s.filterBtn, background: filterCat === c ? undefined : "#131929", color: filterCat === c ? undefined : "#6B7A99", border: filterCat === c ? "none" : "1px solid #2A3352" }}>
                  {c}
                </button>
              ))}
            </div>

            {/* Filtres niveau */}
            <div style={{ ...s.filterRow, marginBottom: 20 }}>
              {["Tous", "Nouvelles", "En retard", "Maîtrisées"].map((l) => (
                <button key={l} onClick={() => setFilterLevel(l)}
                  className={filterLevel === l ? "tab-active hov" : "hov"}
                  style={{ ...s.filterBtn, fontSize: 12, background: filterLevel === l ? undefined : "transparent", color: filterLevel === l ? undefined : "#6B7A99", border: filterLevel === l ? "none" : "1px solid #2A3352" }}>
                  {l}
                </button>
              ))}
            </div>

            {filteredExps.length === 0 ? (
              <div style={s.emptyState}>
                <div style={{ fontSize: 52 }}>📭</div>
                <p style={{ color: "#6B7A99" }}>Aucune fiche trouvée.</p>
                <button onClick={() => setView("add")} style={s.btnPrimary} className="hov">Ajouter une fiche</button>
              </div>
            ) : (
              <div style={s.cardList}>
                {filteredExps.map((exp) => {
                  const lvl = exp.level || 0;
                  const lvlColor = lvl >= 7 ? "#40C080" : lvl >= 5 ? "#4F8EF7" : lvl >= 3 ? "#7B5FF5" : lvl >= 1 ? "#F0A040" : "#6B7A99";
                  const catObj = categories.find((c) => c.name === exp.category);
                  const catColor = catObj?.color || "#4F8EF7";
                  return (
                    <div key={exp.id} style={s.expCard} className="card-hov">
                      <div style={s.expHeader}>
                        <span style={{ ...s.expCat, background: catColor + "22", color: catColor }}>{exp.category}</span>
                        <span style={{ ...s.expLevel, background: lvlColor + "22", color: lvlColor }}>{levelLabel[lvl]}</span>
                      </div>
                      <div style={s.expFront}>{exp.front}</div>
                      <div style={s.expBack}>{exp.back}</div>
                      {exp.example && <div style={s.expEx}><span style={{ color: "#4F8EF7", fontSize: 11, fontFamily: "JetBrains Mono, monospace" }}>// </span>{exp.example}</div>}
                      <div style={s.expFooter}>
                        <span style={s.expDate}>
                          {lvl >= 7 ? "✅ Maîtrisée" : `Révision: ${formatDate(exp.nextReview)}`}
                          {exp.easeFactor && <span style={{ marginLeft: 8, color: "#4F8EF7", fontFamily: "JetBrains Mono, monospace", fontSize: 11 }}>EF:{exp.easeFactor}</span>}
                          {(exp.reviewHistory?.length || 0) > 0 && <span style={{ marginLeft: 8, color: "#6B7A99", fontSize: 11 }}>{exp.reviewHistory.length} révision{exp.reviewHistory.length > 1 ? "s" : ""}</span>}
                        </span>
                        <div style={{ display: "flex", gap: 8 }}>
                          <button onClick={() => startEdit(exp)} style={s.editBtn} className="hov" title="Éditer">✏️</button>
                          <button onClick={() => deleteExp(exp.id)} style={s.delBtn} className="hov" title="Supprimer">🗑️</button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* ════════════════════════════════════════════════════════════════
            MODULES / CATÉGORIES
        ════════════════════════════════════════════════════════════════ */}
        {view === "categories" && (
          <div style={s.fadeIn}>
            <h1 style={s.pageTitle}>◉ Modules académiques</h1>
            <p style={s.pageSub}>Organise par matière avec date d'examen et objectifs</p>

            <div style={s.formCard}>
              <h3 style={{ color: "#1F2937", fontWeight: 700, marginBottom: 16 }}>Nouveau module</h3>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                <div style={s.formGroup}>
                  <label style={s.label}>Nom du module</label>
                  <input value={newCat.name} onChange={(e) => setNewCat((c) => ({ ...c, name: e.target.value }))}
                    style={s.input} placeholder="Ex: 🗄️ Bases de données" />
                </div>
                <div style={s.formGroup}>
                  <label style={s.label}>Date d'examen</label>
                  <input type="date" value={newCat.examDate} onChange={(e) => setNewCat((c) => ({ ...c, examDate: e.target.value }))} style={s.input} />
                </div>
                <div style={s.formGroup}>
                  <label style={s.label}>Objectif maîtrise (%)</label>
                  <input type="number" min={50} max={100} value={newCat.targetScore} onChange={(e) => setNewCat((c) => ({ ...c, targetScore: +e.target.value }))} style={s.input} />
                </div>
                <div style={s.formGroup}>
                  <label style={s.label}>Priorité</label>
                  <select value={newCat.priority} onChange={(e) => setNewCat((c) => ({ ...c, priority: e.target.value }))} style={s.select}>
                    <option value="haute">🔴 Haute</option>
                    <option value="normale">🟡 Normale</option>
                    <option value="faible">🟢 Faible</option>
                  </select>
                </div>
                <div style={s.formGroup}>
                  <label style={s.label}>Couleur du module</label>
                  <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                    {["#4F8EF7", "#F0A040", "#40C080", "#7B5FF5", "#F04040", "#40C0C0", "#F0C040", "#C040F0"].map((color) => (
                      <button key={color} onClick={() => setNewCat((c) => ({ ...c, color }))}
                        style={{ width: 28, height: 28, borderRadius: 8, background: color, border: newCat.color === color ? "3px solid black" : "2px solid transparent", cursor: "pointer" }} />
                    ))}
                  </div>
                </div>
              </div>
              <button className="hov" onClick={handleAddCat} style={s.btnPrimary}>Créer le module</button>
            </div>

            <div style={s.catDetailGrid}>
              {categories.map((cat) => {
                const catExps = expressions.filter((e) => e.category === cat.name);
                const mastered = catExps.filter((e) => e.level >= 7).length;
                const pct = catExps.length ? Math.round((mastered / catExps.length) * 100) : 0;
                const daysToExam = cat.examDate ? Math.ceil((new Date(cat.examDate) - new Date()) / 86400000) : null;
                const priorityColor = cat.priority === "haute" ? "#F04040" : cat.priority === "normale" ? "#F0A040" : "#40C080";
                const catColor = cat.color || "#4F8EF7";
                return (
                  <div key={cat.name} style={{ ...s.catDetailCard, borderTop: `3px solid ${catColor}` }} className="card-hov">
                    <div style={s.catDetailHeader}>
                      <span style={s.catDetailName}>{cat.name}</span>
                      <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                        <span style={{ ...s.priorityTag, background: priorityColor + "22", color: priorityColor }}>{cat.priority}</span>
                        <button onClick={() => { if (window.confirm(`Supprimer "${cat.name}" et toutes ses fiches ?`)) deleteCategory(cat.name); }}
                          style={s.delBtn} className="hov" title="Supprimer le module">🗑️</button>
                      </div>
                    </div>
                    {daysToExam !== null && (
                      <div style={{ ...s.examBadge, marginBottom: 10, background: daysToExam <= 7 ? "#FEE2E2" : "#EFF6FF", color: daysToExam <= 7 ? "#F04040" : catColor }}>
                        📅 {daysToExam > 0 ? `Examen dans ${daysToExam} jours` : "Examen aujourd'hui !"} — {formatDate(cat.examDate)}
                      </div>
                    )}
                    <div style={{ marginBottom: 8, fontSize: 13, color: "#6B7A99" }}>
                      Objectif: <strong style={{ color: catColor }}>{cat.targetScore}%</strong> · Actuel: <strong style={{ color: pct >= cat.targetScore ? "#40C080" : "#F0A040" }}>{pct}%</strong>
                    </div>
                    <div style={{ position: "relative" }}>
                      <div style={s.progressTrack}>
                        <div style={{ ...s.progressFill, width: `${pct}%`, background: pct >= cat.targetScore ? "linear-gradient(90deg,#40C080,#60E0A0)" : `linear-gradient(90deg,${catColor},${catColor}99)` }} />
                      </div>
                      {cat.targetScore < 100 && (
                        <div style={{ position: "absolute", left: `${cat.targetScore}%`, top: 0, bottom: 0, width: 2, background: "#F0A040" }} />
                      )}
                    </div>
                    <div style={{ marginTop: 10, fontSize: 13, color: "#6B7A99" }}>{catExps.length} fiches · {mastered} maîtrisées</div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ════════════════════════════════════════════════════════════════
            MODE EXAMEN
        ════════════════════════════════════════════════════════════════ */}
        {view === "exam" && (
          <div style={s.fadeIn}>
            {!examActive && examAnswers.length === 0 && (
              <>
                <h1 style={s.pageTitle}>🎯 Mode Examen</h1>
                <p style={s.pageSub}>Simule un examen blanc pour mesurer tes connaissances réelles</p>

                <div style={s.formCard}>
                  <h3 style={{ color: "#1F2937", fontWeight: 700, marginBottom: 16 }}>Configuration de l'examen</h3>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 14 }}>
                    <div style={s.formGroup}>
                      <label style={s.label}>Module</label>
                      <select value={examConfig.category} onChange={(e) => setExamConfig((c) => ({ ...c, category: e.target.value }))} style={s.select}>
                        <option value="Toutes">Toutes les matières</option>
                        <option disabled>──────────</option>
                        {catNames.map((c) => <option key={c} value={c}>{c}</option>)}
                      </select>
                    </div>
                    <div style={s.formGroup}>
                      <label style={s.label}>Nombre de questions</label>
                      <input type="number" min={5} max={50} value={examConfig.count} onChange={(e) => setExamConfig((c) => ({ ...c, count: +e.target.value }))} style={s.input} />
                    </div>
                    <div style={s.formGroup}>
                      <label style={s.label}>Temps par carte (sec)</label>
                      <input type="number" min={10} max={120} value={examConfig.timePerCard} onChange={(e) => setExamConfig((c) => ({ ...c, timePerCard: +e.target.value }))} style={s.input} />
                    </div>
                  </div>
                  <div style={s.infoBox}>
                    <span style={{ fontSize: 18 }}>ℹ️</span>
                    <p style={{ color: "#6B7A99", fontSize: 13 }}>
                      En mode examen, <strong style={{ color: "#1D4ED8" }}>les fiches ne sont pas mises à jour</strong> par l'algo SM-2. C'est un test pur. Utilise la révision normale pour l'apprentissage actif.
                    </p>
                  </div>
                  <button className="hov btn-glow" onClick={startExam} style={s.btnPrimary}>🚀 Lancer l'examen</button>
                </div>
              </>
            )}

            {examActive && examCurrentCard && (
              <div style={s.fadeIn}>
                <div style={s.reviewHeader}>
                  <div style={{ fontFamily: "JetBrains Mono, monospace", color: "#4F8EF7", fontWeight: 800 }}>
                    🎯 EXAMEN
                  </div>
                  <div style={{ display: "flex", gap: 16, alignItems: "center" }}>
                    <div style={{ ...s.reviewProgress }}>
                      <span style={{ color: "#4F8EF7", fontWeight: 800 }}>{examIndex + 1}</span>
                      <span style={{ color: "#6B7A99" }}> / {examQueue.length}</span>
                    </div>
                    <div style={{ ...s.timerBadge, background: examTimer <= 10 ? "#F0404022" : "#4F8EF722", color: examTimer <= 10 ? "#F04040" : "#4F8EF7", animation: examTimer <= 5 ? "pulse 0.5s infinite" : "none" }}>
                      ⏱️ {examTimer}s
                    </div>
                  </div>
                </div>
                <div style={s.progressBar}>
                  <div style={{ ...s.progressBarFill, width: `${(examTimer / examConfig.timePerCard) * 100}%`, background: examTimer <= 10 ? "linear-gradient(90deg,#F04040,#F07040)" : "linear-gradient(90deg,#4F8EF7,#7B5FF5)", transition: "width 1s linear, background 0.3s" }} />
                </div>

                <div style={s.flashCard}>
                  <div style={s.cardTop}>
                    <span style={s.catTag}>{examCurrentCard.category}</span>
                    <span style={s.easeTag}>Question {examIndex + 1}</span>
                  </div>
                  <div style={s.cardQ}>
                    <div style={s.cardQLabel}>QUESTION EXAMEN</div>
                    <div style={s.cardQText}>{examCurrentCard.front}</div>
                  </div>
                  {!examRevealed ? (
                    <button className="hov btn-glow" onClick={() => setExamRevealed(true)} style={s.revealBtn}>
                      👁️ Voir la réponse <span style={{ fontSize: 12, opacity: 0.7 }}>(Espace)</span>
                    </button>
                  ) : (
                    <div style={{ animation: "slideIn 0.3s ease" }}>
                      <div style={s.cardA}>
                        <div style={s.cardALabel}>RÉPONSE</div>
                        <div style={s.cardAText}>{examCurrentCard.back}</div>
                        {examCurrentCard.example && <div style={s.cardEx}><span style={{ color: "#4F8EF7", fontSize: 11, fontFamily: "JetBrains Mono, monospace" }}>// exemple</span><br />{examCurrentCard.example}</div>}
                      </div>
                      <div style={s.answerBtns}>
                        <button className="hov" onClick={() => handleExamAnswer(0)} style={s.btnOublie}>😓 Pas su<span style={s.kbKey}>1</span></button>
                        <button className="hov" onClick={() => handleExamAnswer(3)} style={s.btnHesite}>🤔 Hésité<span style={s.kbKey}>2</span></button>
                        <button className="hov" onClick={() => handleExamAnswer(5)} style={s.btnFacile}>⚡ Su<span style={s.kbKey}>3</span></button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Résultats */}
            {!examActive && examAnswers.length > 0 && (
              <div style={s.fadeIn}>
                <h1 style={s.pageTitle}>📊 Résultats de l'examen</h1>
                <div style={{ ...s.statCard, textAlign: "center", padding: "40px", marginBottom: 28, borderTop: `3px solid ${examScore >= 80 ? "#40C080" : examScore >= 60 ? "#F0A040" : "#F04040"}` }}>
                  <div style={{ fontSize: 72, fontWeight: 900, color: examScore >= 80 ? "#40C080" : examScore >= 60 ? "#F0A040" : "#F04040", lineHeight: 1 }}>{examScore}%</div>
                  <div style={{ fontSize: 18, color: "#1F2937", marginTop: 12, fontWeight: 700 }}>
                    {examScore >= 80 ? "🏆 Excellent ! Tu maîtrises le sujet." : examScore >= 60 ? "👍 Pas mal ! Continue à réviser." : "💪 À retravailler. La persévérance paie !"}
                  </div>
                  <div style={{ color: "#6B7A99", marginTop: 8 }}>
                    {examAnswers.filter((a) => a.q >= 3).length} / {examAnswers.length} réponses correctes
                  </div>
                </div>

                {/* Détail par réponse */}
                <div style={s.cardList}>
                  {examAnswers.map(({ card, q }, i) => (
                    <div key={i} style={{ ...s.expCard, borderLeft: `4px solid ${q === 0 ? "#F04040" : q === 3 ? "#F0A040" : "#40C080"}` }}>
                      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
                        <span style={s.expFront}>{card.front}</span>
                        <span style={{ color: q === 0 ? "#F04040" : q === 3 ? "#F0A040" : "#40C080", fontWeight: 700, fontSize: 13 }}>
                          {q === 0 ? "😓 Pas su" : q === 3 ? "🤔 Hésité" : "⚡ Su"}
                        </span>
                      </div>
                      <div style={s.expBack}>{card.back}</div>
                    </div>
                  ))}
                </div>

                <div style={{ display: "flex", gap: 14, marginTop: 24 }}>
                  <button className="hov" onClick={() => { setExamAnswers([]); setExamQueue([]); }} style={s.btnPrimary}>🔄 Nouveau examen</button>
                  <button className="hov" onClick={() => startReview()} style={s.btnSecondary} disabled={todayReviews.length === 0}>
                    📋 Réviser les fiches dues ({todayReviews.length})
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ════════════════════════════════════════════════════════════════
            STATS
        ════════════════════════════════════════════════════════════════ */}
        {view === "stats" && (
          <div style={s.fadeIn}>
            <h1 style={s.pageTitle}>▣ Statistiques</h1>
            <p style={s.pageSub}>Analytique de ta progression d'apprentissage</p>

            <div style={s.infoBox}>
              <span style={{ fontSize: 20 }}>🧠</span>
              <div>
                <strong style={{ color: "#1F2937" }}>Algorithme SuperMemo-2 actif</strong>
                <p style={{ color: "#6B7A99", fontSize: 13, marginTop: 4 }}>
                  Chaque fiche a un <em style={{ color: "#4F8EF7" }}>Easiness Factor (EF)</em> calculé sur tes performances.
                  Les fiches difficiles (EF bas) reviennent plus souvent. Priorité intelligente : les modules avec examens proches passent en premier.
                </p>
              </div>
            </div>

            {/* Heatmap */}
            <h2 style={s.sectionTitle}>🟩 Activité de révision (12 semaines)</h2>
            <div style={s.heatmapCard}>
              <div style={{ display: "flex", gap: 3, alignItems: "flex-start" }}>
                {weeks.map((week, wi) => (
                  <div key={wi} style={{ display: "flex", flexDirection: "column", gap: 3 }}>
                    {week.map((date) => {
                      const cnt = heatmap[date] || 0;
                      const alpha = cnt === 0 ? 0 : Math.min(0.2 + cnt * 0.12, 1);
                      const isToday = date === today();
                      return (
                        <div key={date} title={`${date}: ${cnt} fiche(s)`}
                          style={{ width: 14, height: 14, borderRadius: 3, background: cnt === 0 ? "#EFF6FF" : `rgba(79,142,247,${alpha})`, border: isToday ? "1.5px solid #4F8EF7" : "none", cursor: "default", transition: "all 0.2s" }} />
                      );
                    })}
                  </div>
                ))}
              </div>
              <div style={{ display: "flex", gap: 8, alignItems: "center", marginTop: 14 }}>
                <span style={{ color: "#6B7A99", fontSize: 12 }}>Moins</span>
                {[0, 0.3, 0.55, 0.8, 1].map((a, i) => (
                  <div key={i} style={{ width: 14, height: 14, borderRadius: 3, background: a === 0 ? "#EFF6FF" : `rgba(79,142,247,${a})` }} />
                ))}
                <span style={{ color: "#6B7A99", fontSize: 12 }}>Plus</span>
              </div>
            </div>

            {/* Distribution niveaux */}
            <h2 style={s.sectionTitle}>📊 Distribution des niveaux SM-2</h2>
            <div style={s.levelsChart}>
              {[...Array(8)].map((_, lvl) => {
                const cnt = expressions.filter((e) => e.level === lvl).length;
                const max = Math.max(...[...Array(8)].map((_, i) => expressions.filter((e) => e.level === i).length), 1);
                const colors = ["#F04040", "#F06040", "#F0A040", "#D0C040", "#A0C040", "#40C080", "#4F8EF7", "#7B5FF5"];
                return (
                  <div key={lvl} style={s.levelBar}>
                    <div style={{ fontSize: 11, color: colors[lvl], fontWeight: 700, marginBottom: 4 }}>{cnt}</div>
                    <div style={{ ...s.levelBarFill, height: `${Math.max(4, (cnt / max) * 120)}px`, background: colors[lvl] }} />
                    <div style={{ fontSize: 11, color: "#6B7A99", marginTop: 6 }}>{levelLabel[lvl]?.substring(0, 6)}</div>
                  </div>
                );
              })}
            </div>

            {/* Stats par module */}
            <h2 style={s.sectionTitle}>🔬 Analyse SM-2 par module</h2>
            <div style={s.sm2Grid}>
              {categories.map((cat) => {
                const catExps = expressions.filter((e) => e.category === cat.name && e.easeFactor);
                const avgEF = catExps.length ? (catExps.reduce((a, e) => a + (e.easeFactor || 2.5), 0) / catExps.length).toFixed(2) : "N/A";
                const avgInterval = catExps.length ? Math.round(catExps.reduce((a, e) => a + (e.interval || 1), 0) / catExps.length) : 0;
                const mastered = catExps.filter((e) => e.level >= 7).length;
                const pct = catExps.length ? Math.round((mastered / catExps.length) * 100) : 0;
                const catColor = cat.color || "#4F8EF7";
                return (
                  <div key={cat.name} style={{ ...s.sm2Card, borderTop: `3px solid ${catColor}` }} className="card-hov">
                    <div style={{ fontWeight: 700, color: "#1F2937", marginBottom: 12, fontSize: 14 }}>{cat.name}</div>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, textAlign: "center" }}>
                      <div>
                        <div style={{ fontSize: 20, fontWeight: 800, color: catColor }}>{avgEF}</div>
                        <div style={{ fontSize: 10, color: "#6B7A99" }}>EF moyen</div>
                      </div>
                      <div>
                        <div style={{ fontSize: 20, fontWeight: 800, color: "#40C080" }}>{avgInterval}j</div>
                        <div style={{ fontSize: 10, color: "#6B7A99" }}>Intervalle</div>
                      </div>
                      <div>
                        <div style={{ fontSize: 20, fontWeight: 800, color: "#7B5FF5" }}>{pct}%</div>
                        <div style={{ fontSize: 10, color: "#6B7A99" }}>Maîtrisé</div>
                      </div>
                    </div>
                    <div style={{ ...s.progressTrack, marginTop: 12 }}>
                      <div style={{ ...s.progressFill, width: `${pct}%`, background: `linear-gradient(90deg,${catColor},${catColor}99)` }} />
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Stats globales */}
            <h2 style={s.sectionTitle}>📈 Métriques globales</h2>
            <div style={s.statsGrid}>
              {[
                { icon: "🔁", val: stats.totalReviews, label: "Révisions totales", color: "#4F8EF7" },
                { icon: "🤖", val: stats.aiGenerated, label: "Fiches IA", color: "#7B5FF5" },
                { icon: "🎯", val: stats.examsDone, label: "Examens blancs", color: "#F0A040" },
                { icon: "📅", val: sessions.length, label: "Jours actifs", color: "#40C080" },
              ].map((stat, i) => (
                <div key={i} style={{ ...s.statCard, borderTop: `3px solid ${stat.color}` }} className="card-hov">
                  <div style={s.statIcon}>{stat.icon}</div>
                  <div style={{ ...s.statNum, color: stat.color }}>{stat.val}</div>
                  <div style={s.statLabel}>{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ════════════════════════════════════════════════════════════════
            BADGES
        ════════════════════════════════════════════════════════════════ */}
        {view === "badges" && (
          <div style={s.fadeIn}>
            <h1 style={s.pageTitle}>🏆 Badges & Achievements</h1>
            <p style={s.pageSub}>{unlockedBadges.length} / {BADGES.length} badges débloqués</p>

            <div style={{ ...s.progressTrack, height: 10, marginBottom: 32 }}>
              <div style={{ ...s.progressFill, width: `${(unlockedBadges.length / BADGES.length) * 100}%` }} />
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))", gap: 16 }}>
              {BADGES.map((badge) => {
                const unlocked = unlockedBadges.includes(badge.id);
                return (
                  <div key={badge.id} style={{ ...s.badgeCard, opacity: unlocked ? 1 : 0.4, border: unlocked ? "1px solid #4F8EF755" : "1px solid #EFF6FF" }} className={unlocked ? "card-hov" : ""}>
                    <div style={{ fontSize: 40, marginBottom: 10, filter: unlocked ? "none" : "grayscale(1)" }}>{badge.icon}</div>
                    <div style={{ fontWeight: 700, color: unlocked ? "#1F2937" : "#4B5870", fontSize: 14 }}>{badge.label}</div>
                    <div style={{ color: "#6B7A99", fontSize: 12, marginTop: 4 }}>{badge.desc}</div>
                    {unlocked && <div style={{ marginTop: 10, color: "#40C080", fontSize: 11, fontFamily: "JetBrains Mono, monospace" }}>✓ DÉBLOQUÉ</div>}
                  </div>
                );
              })}
            </div>
          </div>
        )}

      </main>

      <footer style={s.footer}>
        MémoMaître God Level Edition v3 · SM-2 + IA + Voice + Exam Mode · {new Date().getFullYear()} · Dakar 🇸🇳
      </footer>
    </div>
  );
}

// ══════════════════════════════════════════════════════════════════════════════
// CSS GLOBAL
// ══════════════════════════════════════════════════════════════════════════════
const CSS = `
  @import url('https://fonts.googleapis.com/css2?family=Sora:wght@300;400;500;600;700;800;900&family=JetBrains+Mono:wght@400;600;700&display=swap');
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: #F0F5FF; color: #1F2937; } /* Fond clair et texte sombre */
  ::-webkit-scrollbar { width: 6px; }
  ::-webkit-scrollbar-track { background: #EFF6FF; } /* Scrollbar claire */
  ::-webkit-scrollbar-thumb { background: #BFDBFE; border-radius: 3px; } /* Curseur bleu pastel */
  @keyframes fadeUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
  @keyframes spin { to { transform: rotate(360deg); } }
  @keyframes ring { to { transform: rotate(-360deg) scale(1.1); } }
  @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }
  @keyframes slideIn { from { opacity: 0; transform: translateX(24px); } to { opacity: 1; transform: translateX(0); } }
  @keyframes slideDown { from { opacity: 0; transform: translateY(-20px); } to { opacity: 1; transform: translateY(0); } }
  @keyframes glow { 0%,100% { box-shadow: 0 0 15px rgba(29,78,216,0.2); } 50% { box-shadow: 0 0 30px rgba(29,78,216,0.4); } } /* Effet de brillance bleu vif */
  @keyframes badgeIn { from { opacity: 0; transform: translateX(120px); } to { opacity: 1; transform: translateX(0); } }
  .hov:hover { transform: translateY(-2px); transition: all 0.2s ease; }
  .card-hov:hover { transform: translateY(-4px); box-shadow: 0 12px 30px rgba(29,78,216,0.12) !important; transition: all 0.25s; } /* Ombre douce pour fond blanc */
  .mic-pulse { animation: pulse 0.8s infinite; }
  textarea, input, select { font-family: 'Sora', sans-serif !important; color: #1F2937 !important; }
  input:focus, textarea:focus, select:focus { outline: none; border-color: #3B82F6 !important; box-shadow: 0 0 0 3px rgba(59,130,246,0.2) !important; }
  .tab-active { background: rgba(255,255,255,0.2) !important; font-weight: 700 !important; color: white !important; } /* Onglet actif dans la nav bleue */
  .btn-glow:hover { animation: glow 1.5s infinite; transition: all 0.3s; }
  kbd { display: inline-block; padding: 2px 7px; background: #EFF6FF; border: 1px solid #BFDBFE; border-radius: 5px; font-family: 'JetBrains Mono', monospace; font-size: 12px; color: #1D4ED8; font-weight: 600; } /* Touches de clavier stylisées Light Mode */
`;

// ══════════════════════════════════════════════════════════════════════════════
// STYLES
// ══════════════════════════════════════════════════════════════════════════════
const s = {
  // ── BASE & LAYOUT ─────────────────────────────────────────────────────────
  app: { minHeight: "100vh", background: "#F0F5FF", fontFamily: "'Sora', sans-serif", display: "flex", flexDirection: "column", color: "#1F2937" },
  loading: { minHeight: "100vh", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", background: "#F0F5FF", gap: 20 },
  spinnerWrap: { position: "relative", width: 60, height: 60, display: "flex", alignItems: "center", justifyContent: "center" },
  spinner: { width: 36, height: 36, border: "3px solid transparent", borderTop: "3px solid #1D4ED8", borderRadius: "50%", animation: "spin 0.7s linear infinite" },
  spinnerRing: { position: "absolute", inset: 0, border: "3px solid transparent", borderBottom: "3px solid #3B82F655", borderRadius: "50%", animation: "ring 1.2s linear infinite" },
  loadingText: { color: "#1D4ED8", fontWeight: 800, fontSize: 22, letterSpacing: "-0.5px" },
  loadingSub: { color: "#6B7280", fontSize: 13, fontFamily: "JetBrains Mono, monospace" },
  main: { flex: 1, maxWidth: 1000, width: "100%", margin: "0 auto", padding: "32px 20px 80px" },
  fadeIn: { animation: "fadeUp 0.4s ease" },

  // ── NAVIGATION ────────────────────────────────────────────────────────────
  nav: { background: "linear-gradient(135deg, #3B82F6 0%, #1D4ED8 100%)", padding: "0 24px", display: "flex", alignItems: "center", justifyContent: "space-between", position: "sticky", top: 0, zIndex: 100, flexWrap: "wrap", gap: 8, minHeight: 70, boxShadow: "0 4px 15px rgba(29,78,216,0.2)" },
  navBrand: { display: "flex", alignItems: "center", gap: 12 },
  navLogo: { width: 42, height: 42, background: "rgba(255,255,255,0.2)", borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, fontWeight: 900, color: "white", fontFamily: "'JetBrains Mono', monospace" },
  navTitle: { fontSize: 20, fontWeight: 800, color: "white", letterSpacing: "-0.5px" },
  navSub: { fontSize: 10, color: "#DBEAFE", fontFamily: "'JetBrains Mono', monospace", letterSpacing: 1 },
  navLinks: { display: "flex", gap: 4, flexWrap: "wrap" },
  navItem: { padding: "8px 16px", borderRadius: 10, color: "rgba(255,255,255,0.8)", border: "none", cursor: "pointer", fontSize: 13, fontFamily: "'Sora', sans-serif", fontWeight: 600, background: "transparent", transition: "all 0.2s", position: "relative" },
  navBadge: { position: "absolute", top: -2, right: -2, background: "#F59E0B", color: "white", borderRadius: "50%", width: 18, height: 18, fontSize: 10, fontWeight: 900, display: "flex", alignItems: "center", justifyContent: "center", border: "2px solid #1D4ED8" },

  // ── NOTIFICATIONS ─────────────────────────────────────────────────────────
  toast: { position: "fixed", top: 20, right: 20, zIndex: 9999, padding: "14px 22px", borderRadius: 14, color: "white", fontWeight: 600, fontSize: 14, boxShadow: "0 8px 30px rgba(0,0,0,0.15)", animation: "slideIn 0.3s ease" },
  badgeNotif: { position: "fixed", top: 90, right: 20, zIndex: 9998, display: "flex", gap: 16, alignItems: "center", background: "white", border: "2px solid #F59E0B", borderRadius: 18, padding: "18px 24px", boxShadow: "0 12px 40px rgba(245,158,11,0.2)", animation: "badgeIn 0.4s ease" },

  // ── EN-TÊTES DE PAGES (Classique & Centré) ────────────────────────────────
  pageHeader: { display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 28, flexWrap: "wrap", gap: 12 },
  pageTitle: { fontSize: 28, fontWeight: 900, color: "#1D4ED8", letterSpacing: "-1px" },
  pageSub: { color: "#6B7280", fontSize: 14, marginTop: 6 },
  pageHeaderCenter: { textAlign: "center", marginBottom: 40, marginTop: 20 },
  pageTitleCenter: { fontSize: 42, fontWeight: 800, color: "#1D4ED8", letterSpacing: "-1px" },
  pageSubCenter: { color: "#6B7280", fontSize: 18, marginTop: 8, fontWeight: 500 },
  streakBadge: { background: "#FEF3C7", border: "1px solid #FDE68A", borderRadius: 14, padding: "10px 18px", color: "#D97706", fontWeight: 800, fontSize: 16 },
  sectionTitle: { fontSize: 14, fontWeight: 700, color: "#1D4ED8", marginBottom: 16, marginTop: 32, fontFamily: "'JetBrains Mono', monospace", letterSpacing: 1, textTransform: "uppercase" },
  sectionTitleLight: { fontSize: 18, fontWeight: 700, color: "#1D4ED8", marginBottom: 16, marginTop: 32 },

  // ── DASHBOARD STATS & BANNIÈRES ───────────────────────────────────────────
  statsGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 16, marginBottom: 32 },
  statCard: { background: "white", borderRadius: 20, padding: "24px 16px", textAlign: "center", border: "1px solid #EFF6FF", boxShadow: "0 4px 15px rgba(29,78,216,0.04)", transition: "all 0.25s" },
  statIcon: { fontSize: 28, marginBottom: 12 },
  statNum: { fontSize: 38, fontWeight: 900, lineHeight: 1, color: "#1D4ED8" },
  statLabel: { fontSize: 13, color: "#6B7280", marginTop: 8, fontWeight: 600 },
  reviewBanner: { background: "linear-gradient(135deg, #1D4ED8, #3B82F6)", borderRadius: 22, padding: "24px 30px", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 14, marginBottom: 32, boxShadow: "0 10px 30px rgba(29,78,216,0.2)" },
  bannerTitle: { color: "white", fontSize: 18, fontWeight: 800 },
  bannerSub: { color: "rgba(255,255,255,0.8)", fontSize: 14, marginTop: 4 },
  reviewBannerBlue: { background: "#3B82F6", borderRadius: 20, padding: "30px", textAlign: "center", boxShadow: "0 10px 30px rgba(59,130,246,0.3)", marginBottom: 32 },
  bannerTitleWhite: { color: "white", fontSize: 22, fontWeight: 800, marginBottom: 8 },
  bannerSubWhite: { color: "rgba(255,255,255,0.9)", fontSize: 15, marginBottom: 16 },
  btnWhite: { background: "white", color: "#1D4ED8", border: "none", borderRadius: 12, padding: "12px 26px", fontWeight: 800, fontSize: 14, cursor: "pointer", fontFamily: "'Sora', sans-serif", whiteSpace: "nowrap" },

  // ── MODULES GRID ──────────────────────────────────────────────────────────
  modulesGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 16 },
  moduleCard: { background: "white", border: "1px solid #EFF6FF", borderRadius: 20, padding: "20px", transition: "all 0.25s", boxShadow: "0 4px 15px rgba(29,78,216,0.04)" },
  moduleCardLight: { background: "white", borderRadius: 20, padding: "20px", boxShadow: "0 4px 15px rgba(29,78,216,0.04)", border: "1px solid #EFF6FF", transition: "all 0.25s" },
  moduleName: { fontWeight: 800, color: "#1F2937", fontSize: 15, marginBottom: 12 },
  moduleNameLight: { fontWeight: 800, color: "#1F2937", fontSize: 16, marginBottom: 12 },
  examBadge: { borderRadius: 8, padding: "5px 10px", fontSize: 12, fontWeight: 700, marginBottom: 12, display: "inline-block" },
  progressWrap: { display: "flex", alignItems: "center", gap: 10, marginBottom: 12 },
  progressTrack: { flex: 1, height: 8, background: "#EFF6FF", borderRadius: 4, overflow: "hidden", position: "relative" },
  progressTrackLight: { flex: 1, height: 8, background: "#EFF6FF", borderRadius: 4, overflow: "hidden" },
  progressFill: { height: "100%", borderRadius: 4, transition: "width 0.5s ease", background: "linear-gradient(90deg, #1D4ED8, #60A5FA)" },
  progressFillLight: { height: "100%", borderRadius: 4, transition: "width 0.5s ease" },
  pctLabel: { fontSize: 13, fontWeight: 800, color: "#1D4ED8", minWidth: 38 },
  moduleStats: { display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: 13 },
  quickReviewBtn: { color: "white", border: "none", borderRadius: 8, padding: "6px 12px", fontSize: 11, fontWeight: 700, cursor: "pointer", fontFamily: "'Sora', sans-serif" },

  // ── LISTES & UPCOMING ─────────────────────────────────────────────────────
  upcomingList: { display: "flex", flexDirection: "column", gap: 10, marginBottom: 24 },
  upcomingItem: { background: "white", border: "1px solid #EFF6FF", borderRadius: 14, padding: "14px 18px", display: "flex", alignItems: "center", gap: 12, boxShadow: "0 2px 8px rgba(29,78,216,0.03)" },
  upcomingItemLight: { background: "white", border: "1px solid #EFF6FF", borderRadius: 14, padding: "14px 20px", display: "flex", alignItems: "center", gap: 12, boxShadow: "0 2px 8px rgba(29,78,216,0.03)" },
  upcomingFront: { flex: 1, color: "#1F2937", fontSize: 14, fontWeight: 700 },
  upcomingFrontLight: { flex: 1, color: "#1F2937", fontSize: 15, fontWeight: 700 },
  upcomingCat: { color: "#1D4ED8", fontSize: 12, background: "#EFF6FF", padding: "4px 12px", borderRadius: 20, fontWeight: 600 },
  upcomingCatLight: { color: "#1D4ED8", fontSize: 12, background: "#EFF6FF", padding: "4px 12px", borderRadius: 20, fontWeight: 600 },
  upcomingDate: { color: "#6B7280", fontSize: 12, fontFamily: "JetBrains Mono, monospace" },
  upcomingDateLight: { color: "#6B7280", fontSize: 13, fontWeight: 500 },

  // ── MODE RÉVISION (Flashcards) ────────────────────────────────────────────
  reviewHeader: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 },
  backBtn: { background: "white", border: "1px solid #DBEAFE", borderRadius: 10, padding: "8px 16px", color: "#1D4ED8", cursor: "pointer", fontSize: 13, fontWeight: 600, fontFamily: "'Sora', sans-serif", transition: "all 0.2s" },
  reviewProgress: { fontFamily: "'JetBrains Mono', monospace", fontSize: 15, color: "#6B7280" },
  progressBar: { height: 8, background: "#DBEAFE", borderRadius: 4, marginBottom: 32, overflow: "hidden" },
  progressBarFill: { height: "100%", background: "linear-gradient(90deg, #1D4ED8, #3B82F6)", borderRadius: 4, transition: "width 0.4s ease" },
  timerBadge: { padding: "6px 14px", borderRadius: 10, fontFamily: "JetBrains Mono, monospace", fontWeight: 800, fontSize: 14 },
  flashCard: { background: "white", border: "1px solid #EFF6FF", borderRadius: 26, padding: "32px", boxShadow: "0 10px 40px rgba(29,78,216,0.08)", maxWidth: 700, margin: "0 auto" },
  cardTop: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 },
  catTag: { background: "#EFF6FF", color: "#1D4ED8", padding: "6px 14px", borderRadius: 20, fontSize: 12, fontWeight: 700 },
  easeTag: { background: "#F5F3FF", color: "#7C3AED", padding: "6px 14px", borderRadius: 20, fontSize: 11, fontWeight: 700, fontFamily: "'JetBrains Mono', monospace" },
  cardQ: { background: "#F8FAFF", borderRadius: 20, padding: "28px", marginBottom: 20, border: "1px solid #EFF6FF" },
  cardQLabel: { fontSize: 11, color: "#60A5FA", fontWeight: 800, letterSpacing: 2, marginBottom: 14, fontFamily: "'JetBrains Mono', monospace" },
  cardQText: { fontSize: 26, fontWeight: 800, color: "#1D4ED8", lineHeight: 1.35 },
  revealBtn: { display: "block", width: "100%", padding: "18px", background: "linear-gradient(135deg, #1D4ED8, #3B82F6)", color: "white", border: "none", borderRadius: 16, fontSize: 16, fontWeight: 700, cursor: "pointer", fontFamily: "'Sora', sans-serif" },
  kbHint: { textAlign: "center", marginTop: 12, color: "#9CA3AF", fontSize: 12 },
  cardA: { background: "#EFF6FF", border: "2px solid #DBEAFE", borderRadius: 20, padding: "28px", marginBottom: 20 },
  cardALabel: { fontSize: 11, color: "#3B82F6", fontWeight: 800, letterSpacing: 2, marginBottom: 14, fontFamily: "'JetBrains Mono', monospace" },
  cardAText: { fontSize: 18, fontWeight: 600, color: "#1F2937", lineHeight: 1.6 },
  cardEx: { marginTop: 16, padding: "14px 18px", background: "white", borderRadius: 12, fontSize: 14, color: "#4B5563", fontStyle: "italic", borderLeft: "4px solid #3B82F6" },
  
  // ── BOUTONS DE RÉPONSE ────────────────────────────────────────────────────
  answerBtns: { display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 },
  btnOublie: { position: "relative", padding: "16px 8px", background: "#FEE2E2", color: "#B91C1C", border: "1px solid #FECACA", borderRadius: 16, fontWeight: 700, cursor: "pointer", fontSize: 14, fontFamily: "'Sora', sans-serif", lineHeight: 1.5 },
  btnHesite: { position: "relative", padding: "16px 8px", background: "#FEF3C7", color: "#B45309", border: "1px solid #FDE68A", borderRadius: 16, fontWeight: 700, cursor: "pointer", fontSize: 14, fontFamily: "'Sora', sans-serif", lineHeight: 1.5 },
  btnFacile: { position: "relative", padding: "16px 8px", background: "#D1FAE5", color: "#047857", border: "1px solid #A7F3D0", borderRadius: 16, fontWeight: 700, cursor: "pointer", fontSize: 14, fontFamily: "'Sora', sans-serif", lineHeight: 1.5 },
  kbKey: { position: "absolute", top: 8, right: 10, fontSize: 10, opacity: 0.6, fontFamily: "JetBrains Mono, monospace", background: "white", padding: "2px 6px", borderRadius: 6, border: "1px solid rgba(0,0,0,0.1)" },
  cardHistory: { display: "flex", alignItems: "center", gap: 6, marginTop: 20, justifyContent: "center" },
  histDot: { width: 10, height: 10, borderRadius: "50%", display: "inline-block" },

  // ── FORMULAIRES & IA ──────────────────────────────────────────────────────
  aiBlock: { background: "#EFF6FF", border: "1px solid #DBEAFE", borderRadius: 22, padding: "24px", marginBottom: 24 },
  aiHeader: { display: "flex", gap: 14, alignItems: "center" },
  aiIcon: { fontSize: 32, lineHeight: 1 },
  aiInput: { flex: 1, padding: "14px 18px", background: "white", border: "1px solid #DBEAFE", borderRadius: 12, fontSize: 14, color: "#1F2937", fontFamily: "'Sora', sans-serif" },
  aiBtn: { padding: "14px 24px", background: "linear-gradient(135deg, #1D4ED8, #3B82F6)", color: "white", border: "none", borderRadius: 12, fontWeight: 700, fontSize: 14, cursor: "pointer", fontFamily: "'Sora', sans-serif", whiteSpace: "nowrap" },
  formCard: { background: "white", border: "1px solid #EFF6FF", borderRadius: 22, padding: "30px", marginBottom: 24, boxShadow: "0 4px 15px rgba(29,78,216,0.03)" },
  formGroup: { marginBottom: 20 },
  label: { display: "block", fontSize: 13, fontWeight: 700, color: "#4B5563", marginBottom: 8 },
  input: { width: "100%", padding: "14px 16px", background: "white", border: "2px solid #EFF6FF", borderRadius: 12, fontSize: 14, color: "#1F2937", transition: "all 0.2s" },
  select: { width: "100%", padding: "14px 16px", background: "white", border: "2px solid #EFF6FF", borderRadius: 12, fontSize: 14, color: "#1F2937", cursor: "pointer" },
  micBtn: { position: "absolute", right: 12, top: "50%", transform: "translateY(-50%)", background: "white", border: "none", cursor: "pointer", fontSize: 18, padding: 6, borderRadius: "50%", boxShadow: "0 2px 5px rgba(0,0,0,0.05)" },
  listeningBadge: { marginTop: 8, fontSize: 12, color: "#EF4444", fontWeight: 700, fontFamily: "'JetBrains Mono', monospace" },
  btnPrimary: { padding: "14px 28px", background: "linear-gradient(135deg, #1D4ED8, #3B82F6)", color: "white", border: "none", borderRadius: 12, fontSize: 14, fontWeight: 700, cursor: "pointer", fontFamily: "'Sora', sans-serif" },
  btnSecondary: { padding: "14px 24px", background: "#F8FAFF", color: "#1D4ED8", border: "1px solid #DBEAFE", borderRadius: 12, fontSize: 14, fontWeight: 700, cursor: "pointer", fontFamily: "'Sora', sans-serif" },

  // ── LISTE DES FICHES ──────────────────────────────────────────────────────
  filterRow: { display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 16 },
  filterBtn: { padding: "8px 18px", borderRadius: 20, fontSize: 13, fontWeight: 600, cursor: "pointer", fontFamily: "'Sora', sans-serif", border: "1px solid #DBEAFE", background: "white", color: "#4B5563" },
  cardList: { display: "flex", flexDirection: "column", gap: 14 },
  expCard: { background: "white", border: "1px solid #EFF6FF", borderRadius: 20, padding: "24px", transition: "all 0.25s", boxShadow: "0 2px 10px rgba(29,78,216,0.03)" },
  expHeader: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 },
  expCat: { padding: "4px 12px", borderRadius: 20, fontSize: 12, fontWeight: 700 },
  expLevel: { padding: "4px 12px", borderRadius: 20, fontSize: 12, fontWeight: 700 },
  expFront: { fontSize: 18, fontWeight: 800, color: "#1D4ED8", marginBottom: 8 },
  expBack: { fontSize: 15, color: "#4B5563", marginBottom: 8, lineHeight: 1.5 },
  expEx: { fontSize: 13, color: "#9CA3AF", fontStyle: "italic", marginBottom: 8 },
  expFooter: { display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 16, paddingTop: 16, borderTop: "1px solid #EFF6FF" },
  expDate: { fontSize: 12, color: "#60A5FA", fontFamily: "'JetBrains Mono', monospace", fontWeight: 600 },
  editBtn: { background: "#EFF6FF", border: "none", cursor: "pointer", fontSize: 15, padding: "6px 10px", borderRadius: 8, color: "#1D4ED8" },
  delBtn: { background: "#FEF2F2", border: "none", cursor: "pointer", fontSize: 15, padding: "6px 10px", borderRadius: 8, color: "#EF4444" },
  emptyState: { textAlign: "center", padding: "80px 20px", display: "flex", flexDirection: "column", alignItems: "center", gap: 16 },

  // ── CATÉGORIES (VUE DÉTAILLÉE) ────────────────────────────────────────────
  catDetailGrid: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 20 },
  catDetailCard: { background: "white", border: "1px solid #EFF6FF", borderRadius: 22, padding: "26px", transition: "all 0.25s", boxShadow: "0 4px 15px rgba(29,78,216,0.04)" },
  catDetailHeader: { display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 },
  catDetailName: { fontWeight: 900, color: "#1F2937", fontSize: 18 },
  priorityTag: { padding: "4px 12px", borderRadius: 20, fontSize: 12, fontWeight: 700 },
  infoBox: { background: "#EFF6FF", border: "1px solid #DBEAFE", borderRadius: 16, padding: "20px", display: "flex", gap: 16, alignItems: "flex-start", marginBottom: 30 },

  // ── STATS & GRAPHIQUES ────────────────────────────────────────────────────
  heatmapCard: { background: "white", border: "1px solid #EFF6FF", borderRadius: 22, padding: "28px", marginBottom: 32, overflowX: "auto", boxShadow: "0 4px 15px rgba(29,78,216,0.03)" },
  levelsChart: { display: "flex", gap: 12, alignItems: "flex-end", height: 220, background: "white", border: "1px solid #EFF6FF", borderRadius: 22, padding: "24px", marginBottom: 32, boxShadow: "0 4px 15px rgba(29,78,216,0.03)" },
  levelBar: { flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "flex-end" },
  levelBarFill: { width: "100%", minWidth: 24, borderRadius: "6px 6px 0 0", transition: "height 0.5s ease" },
  sm2Grid: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 16, marginBottom: 32 },
  sm2Card: { background: "white", border: "1px solid #EFF6FF", borderRadius: 20, padding: "24px", transition: "all 0.25s", boxShadow: "0 4px 15px rgba(29,78,216,0.03)" },
  badgeCard: { background: "white", border: "1px solid #EFF6FF", borderRadius: 22, padding: "28px", textAlign: "center", transition: "all 0.25s", boxShadow: "0 4px 15px rgba(29,78,216,0.03)" },

  // ── PIED DE PAGE ──────────────────────────────────────────────────────────
  footer: { textAlign: "center", padding: "24px", color: "#9CA3AF", fontSize: 12, borderTop: "1px solid #DBEAFE", fontFamily: "'JetBrains Mono', monospace", background: "transparent" },
};
